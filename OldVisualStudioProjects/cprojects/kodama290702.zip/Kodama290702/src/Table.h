
class HashTable 
{
public:
	void Insert(int key, int a) { 
		// 
	};
	void Find (int key) { return elements[key]; };
	
}